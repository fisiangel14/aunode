'use strict';

describe('Component: RiskTemplateComponent', function () {

  // load the controller's module
  beforeEach(module('amxApp'));

  var RiskTemplateComponent;

  // Initialize the controller and a mock scope
  beforeEach(inject(function ($componentController) {
    RiskTemplateComponent = $componentController('riskTemplate', {});
  }));

  it('should ...', function () {
    expect(1).to.equal(1);
  });
});
