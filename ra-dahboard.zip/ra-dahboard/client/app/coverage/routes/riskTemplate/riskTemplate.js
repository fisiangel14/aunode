'use strict';

angular.module('amxApp')
  .config(function ($stateProvider) {
    $stateProvider
      .state('riskTemplate', {
        url: '/risk-template?opcoId',
        template: '<risk-template></risk-template>',
				data: {
          requireLogin: true,
          title: 'Template based risk validation',
          leftMenu: 'Coverage',
          showOpcoFilter: true
        }         
      });
  });
