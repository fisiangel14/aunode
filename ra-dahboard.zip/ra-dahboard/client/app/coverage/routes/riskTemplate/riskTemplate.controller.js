'use strict';

(function(){

class RiskTemplateComponent {
  constructor($scope, Entry, Coverage, $filter, $timeout, $state, $stateParams, CommentModal, $uibModal) {
    $scope.entry = Entry;
    $scope.businessProcesses = [];
    $scope.lobs = [];
    $scope.productSegments = [];
    $scope.selectedProductSegments = [];
    $scope.filteredRiskNodes = [];
    $scope.groupFilteredProductSegments = [];
    $scope.productGroups = [];
    $scope.loadFinished = false;
    $scope.isDisabled = $scope.entry.isDisabled();
    $scope.currentProductGroup = '';
    $scope._und = _;
    $scope.showIgnored = 'N';

    if ($stateParams.opcoId === undefined) {
      $state.go('productSegmentTable', {opcoId: $scope.entry.OPCO_ID}, {reload: true});
    }

    var applyBusinessProcessFilter = function() {
      $scope.businessProcesses = _.map(_.groupBy($scope.filteredRiskNodes, 'BUSINESS_PROCESS_ID'), function(g) {
        return { 
            BUSINESS_PROCESS: _.reduce(g, function(m,x) { return x.BUSINESS_PROCESS; }, 0),
            BUSINESS_PROCESS_ID: _.reduce(g, function(m,x) { return x.BUSINESS_PROCESS_ID; }, 0),
            LOB_COUNT: _.reduce(g, function(m,x) { return m + 1; }, 0),
            COVERAGE: _.reduce(g, function(m,x) { return m + x.COVERAGE_CHANGE; }, 0),
          };    
      });
    };

    $scope.loadData = function(){
      $scope.loadFinished = false;
      $scope.filteredRiskNodes = [];
      $scope.groupFilteredProductSegments = []; 

      Coverage.getRiskTemplate($stateParams.opcoId, $scope.showIgnored)
        .then(function(data){
          $scope.productSegments = data;
          //$scope.productSegments.forEach(function(e){e.COVERAGE = Math.floor(Math.random() * 100 + 1);})

          $scope.lobs = _.map(_.groupBy(data, 'LOB'), function(g) {
            return { 
                LOB: _.reduce(g, function(m,x) { return x.LOB; }, 0),
                LOB_COUNT: _.reduce(g, function(m,x) { return m + 1; }, 0),
                COVERAGE: _.reduce(g, function(m,x) { return m + x.COVERAGE_CHANGE; }, 0),
              };
          });

          var total = _.map(_.groupBy(data, 'OPCO_ID'), function(g) {
            return { 
                LOB: _.reduce(g, function(m,x) { return 0; }, 0),
                LOB_COUNT: _.reduce(g, function(m,x) { return m + 1; }, 0),
                COVERAGE: _.reduce(g, function(m,x) { return m + x.COVERAGE_CHANGE; }, 0),
              };
          });
          $scope.lobs.push(total[0]);

          $scope.productGroups = _.map(_.groupBy(data, 'PRODUCT_GROUP_ID'), function(g) {
            return { 
                LOB: _.reduce(g, function(m,x) { return x.LOB; }, 0),
                PRODUCT_GROUP: _.reduce(g, function(m,x) { return x.PRODUCT_GROUP; }, 0),
                PRODUCT_GROUP_ID: _.reduce(g, function(m,x) { return x.PRODUCT_GROUP_ID; }, 0),
                LOB_COUNT: _.reduce(g, function(m,x) { return m + 1; }, 0),
                COVERAGE: _.reduce(g, function(m,x) { return m + x.COVERAGE_CHANGE; }, 0),
              };
          });
         
          if (_.size($scope.entry.searchRiskTemplate) > 0) {
            $scope.filteredRiskNodes = $filter('filter') ($scope.productSegments, $scope.entry.searchRiskTemplate);
            $scope.groupFilteredProductSegments = _.groupBy($scope.filteredRiskNodes, 'PRODUCT_SEGMENT');
          }
          else {
            $scope.filteredRiskNodes = $scope.productSegments;
            $scope.groupFilteredProductSegments = _.groupBy($scope.filteredRiskNodes, 'PRODUCT_SEGMENT');
          }

          applyBusinessProcessFilter();
          $scope.loadFinished = true;

      });
    };
    $scope.loadData();

    $scope.removeAllFilters = function () {
      $scope.entry.searchRiskTemplate = {};
    };

    $scope.removeFilter = function (element) {
      delete $scope.entry.searchRiskTemplate[element];
      if (_.size($scope.entry.searchRiskTemplate) === 0) {
        $scope.entry.searchRiskTemplate = {};
      }
    };

    $scope.setFilterLob = function (lob) {
      if (lob) {
        delete $scope.entry.searchRiskTemplate.BUSINESS_PROCESS;
        delete $scope.entry.searchRiskTemplate.PRODUCT_GROUP_ID;        
        $scope.entry.searchRiskTemplate.LOB = lob;
      }
      else {
        delete $scope.entry.searchRiskTemplate.BUSINESS_PROCESS;
        delete $scope.entry.searchRiskTemplate.PRODUCT_GROUP_ID;        
        delete $scope.entry.searchRiskTemplate.LOB;
      }
    };
        
    $scope.setFilterProductGroup = function (productGroupId) {
      if (productGroupId) {
        $scope.entry.searchRiskTemplate.PRODUCT_GROUP_ID = productGroupId;
        $scope.currentProductGroup =  _.find($scope.productGroups, function(value, key, object) {
          return value.PRODUCT_GROUP_ID == productGroupId; 
        }).PRODUCT_GROUP;
        delete $scope.entry.searchRiskTemplate.BUSINESS_PROCESS;
      }
      else {
        delete $scope.entry.searchRiskTemplate.PRODUCT_GROUP_ID;
        delete $scope.entry.searchRiskTemplate.PRODUCT_GROUP;
        delete $scope.entry.searchRiskTemplate.BUSINESS_PROCESS;
        delete $scope.currentProductGroup;
      }
    };

    $scope.unlinkSubRisk = function(rnSubriskId) {
			Coverage.unlinkSubRisk(rnSubriskId).then(function(response){
        Entry.showToast('Risk node modified. All changes saved!');
				if (response.success) { 
          $scope.productSegments = _.reject($scope.productSegments, function(e){
            return e.RN_SUB_RISK_ID == rnSubriskId;
          });
          timeoutFilterChange();
          Entry.showToast('Risk node modified. All changes saved!');
				}
				else {
					Entry.showToast('Delete action failed. Error ' + response.err);
				}
			});
		};

    $scope.addRiskNode = function(riskNode) {

      // append sub-risk
      riskNode.SUB_RISKS = [angular.copy(riskNode)];

      Coverage.postRiskNode(riskNode).then(function(response){
        if (response.success) { 
          // redirect if successfull
          Entry.showToast('Risk node added. Redirecting to edit');
          $state.go('riskNodeTable', {productSegmentId: riskNode.PRODUCT_SEGMENT_ID, riskId: riskNode.RISK_ID, tabId: riskNode.active}, {reload: true});
        }
        else {
          Entry.showToast('Action failed. Error ' + response.err);
        }
      });

		};

    $scope.ignoreTemplateSubRisk = function(riskNode) {

      if (riskNode.IGNORED === 'Y') {

        CommentModal().then(function (modalData) {
          
          riskNode.CREATED_BY = $scope.entry.currentUser.userName;
          
          if (typeof modalData !== 'undefined') {
            riskNode.NOTE = modalData.COMMENT;
          }
                    
          Coverage.addIgnoreTemplate(riskNode)
            .then(function (data) { 
                if (data.success) { Entry.showToast('Ignore condition added'); }
              });
            }).catch(function (err) {
              Entry.showToast('No action. ' + err);
              riskNode.IGNORED = 'N';
            });
      }
      else {

        Coverage.deleteIgnoreTemplate(riskNode.TAG)
        .then(function (data) { 
            if (data.success) { Entry.showToast('Ignore condition deleted'); }
        });

      }

		};

		$scope.setFilterBusinessProcess = function (businessProcesses) {
			if (businessProcesses) {
				$scope.entry.searchRiskTemplate.BUSINESS_PROCESS = businessProcesses;
			}
			else {
				delete $scope.entry.searchRiskTemplate.BUSINESS_PROCESS;
			}

			$timeout(function(){ 

				// remove filters with blank values
				$scope.entry.searchRiskTemplate = _.pick($scope.entry.searchRiskTemplate, function(value, key, object) {
					return value !== '' && value !== null;
				});
				
				if (_.size($scope.entry.searchRiskTemplate) === 0) {
					$scope.entry.searchRiskTemplate = {};
				}

			}, 400);


		};    

    // Watch filter change
    var timeoutFilterChange = function(){
    
        $timeout(function(){

          // remove filters with blank values
          $scope.entry.searchRiskTemplate = _.pick($scope.entry.searchRiskTemplate, function(value, key, object) {
            return value !== '' && value !== null;
          });
          
          if (_.size($scope.entry.searchRiskTemplate) === 0) {
            //delete $scope.entry.searchRiskTemplate;
            $scope.entry.searchRiskTemplate = {};
          }

          if (_.size($scope.entry.searchRiskTemplate) > 0) {
            $scope.filteredRiskNodes = $filter('filter') ($scope.productSegments, $scope.entry.searchRiskTemplate);
          }
          else {
            $scope.filteredRiskNodes = $scope.productSegments;
          }
          
          applyBusinessProcessFilter();

          $scope.groupFilteredProductSegments = _.groupBy($scope.filteredRiskNodes, 'PRODUCT_SEGMENT');

        }, 400);
    };

    $scope.$watch('entry.searchRiskTemplate', timeoutFilterChange, true);     

    $scope.$watch('entry.OPCO_ID', function(){
      setTimeout (function () {
        $state.go('riskTemplate', {opcoId: $scope.entry.OPCO_ID} );
      }, 300); 
    });        
  }
}

angular.module('amxApp')
  .component('riskTemplate', {
    templateUrl: 'app/coverage/routes/riskTemplate/riskTemplate.html',
    controller: RiskTemplateComponent,
    controllerAs: 'riskTemplateCtrl'
  });

})();
