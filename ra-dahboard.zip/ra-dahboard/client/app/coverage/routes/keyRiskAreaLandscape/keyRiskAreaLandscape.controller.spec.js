'use strict';

describe('Component: KeyRiskAreaLandscapeComponent', function () {

  // load the controller's module
  beforeEach(module('amxApp'));

  var KeyRiskAreaLandscapeComponent;

  // Initialize the controller and a mock scope
  beforeEach(inject(function ($componentController) {
    KeyRiskAreaLandscapeComponent = $componentController('keyRiskAreaLandscape', {});
  }));

  it('should ...', function () {
    expect(1).to.equal(1);
  });
});
