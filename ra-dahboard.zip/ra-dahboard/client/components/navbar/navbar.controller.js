'use strict';

class NavbarController {}

//end-non-standard

angular.module('amxApp')
  .controller('NavbarController', NavbarController);
