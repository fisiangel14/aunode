'use strict';

angular.module('amxApp.util', []);
